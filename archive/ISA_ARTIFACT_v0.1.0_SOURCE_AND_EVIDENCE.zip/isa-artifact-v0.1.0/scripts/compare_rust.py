"""Full Rust/Python differential check. Requires real compiled Rust executables."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import subprocess
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'research/reference'))
from wire import load
from scenarios import IDS

def main():
    p=argparse.ArgumentParser();p.add_argument('--checker',type=Path,required=True);args=p.parse_args()
    subprocess.run([sys.executable,str(ROOT/'research/reference/run.py'),'--backend','rust','--checker',str(args.checker),'--out',str(ROOT/'results/rust-checker-differential')],check=True,timeout=90)
    comparisons=0
    for name in IDS:
        ref=load((ROOT/'results/reference/cases'/name/'report.isa').read_bytes())
        alt=load((ROOT/'results/rust-checker-differential/cases'/name/'report.isa').read_bytes())
        actual=load((ROOT/'results/rust/cases'/name/'report.isa').read_bytes())
        assert ref==alt==actual,(name,'Rust/Python report disagreement')
        for filename in ('context.isa','collector-seal.isa','evidence.isa','observation-omega0.isa','system-evidence.isa','system-report.isa'):
            assert (ROOT/'results/reference/cases'/name/filename).read_bytes()==(ROOT/'results/rust/cases'/name/filename).read_bytes(),(name,filename)
            comparisons+=1
        comparisons+=2
    report={'status':'PASS','scenarios':len(IDS),'comparisons':comparisons,'rust_actually_executed':True}
    (ROOT/'results/validation/rust-differential.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
if __name__=='__main__':main()
