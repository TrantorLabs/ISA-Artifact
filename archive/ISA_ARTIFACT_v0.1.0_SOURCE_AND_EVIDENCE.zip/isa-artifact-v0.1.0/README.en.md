# ISA executable research artifact

This is a deterministic research implementation of the frozen ISA v1.2 FINAL paper: actual formation, evidence production, evidence-only checking, research-only ground truth, and finite formal counterexamples.

**Delivery status: VALIDATION_INCOMPLETE.** Seven standard-library-only Rust crates are supplied in separate runtime and research workspaces. Rust compilation and Cargo tests were **not run** because the build environment contains no Rust compiler/Cargo and cannot download a toolchain. The executed results in this archive are explicitly labeled **Python reference execution** and **native Z3 formal queries**. They are not substituted for Rust validation.

Run `python3 scripts/verify.py --reference-only` for the reference/formal suite (Python 3.11+, Z3 shared library or executable). Install the pinned Rust 1.85.0 toolchain and run `python3 scripts/verify.py` for full gates, including actual Rust execution and cross-language comparisons. Missing tools fail the full release gate.

The central pair uses the same ordinary outcome and policy results: one controller genuinely gates admission, another only runs shadow checks. Protected formation-bound evidence distinguishes them; missing required evidence yields Unadjudicable. The reference suite includes 22 directed scenarios, separate Oracle checks, checker mutation tests and exact reproduction. Z3 executes 17 queries in eight groups and an independent enumerator visits 2,560 finite worlds.

Collector authenticity and complete observation are explicit synthetic trust assumptions. Checksums are not authentication; a process boundary is not a hostile-host sandbox. The compromised-trust-root counterexample is deliberately retained. No production payments, deployed AI safety guarantees, empirical risk-reduction claims or universal formal proofs are supplied.

See the Chinese [README](README.md), [traceability](docs/TRACEABILITY.md), [reproducibility](docs/REPRODUCIBILITY.md), [delta ledger](docs/decisions/ARTIFACT_DELTA.md) and [security scope](SECURITY.md). Machine status: `results/validation/verification.json`.
