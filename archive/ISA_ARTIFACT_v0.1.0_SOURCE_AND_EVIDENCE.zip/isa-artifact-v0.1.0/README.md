# ISA 可执行研究工件

**让同样正确的付款，暴露不同的控制关系；让不知道答案的检查器，只凭合法证据作出判定。**

本仓库以 ISA v1.2 FINAL 为定义依据，将判断—行动形成结构、真实准入控制、结构证据、独立审计与三种判定实现为一个有限、确定性的研究世界。它不是生产支付系统，也不是总体 AI 安全认证工具。

## 当前交付状态：源码与已执行证据，不是已验证的 Rust 发布版

**版本标识：0.1.0，状态：`VALIDATION_INCOMPLETE`。**

本次环境没有 Rust 编译器、Cargo 或 rustfmt，外部下载也不可用。因此，**Rust 源码已经写出，但 Rust 编译、Cargo 测试、Rust/Python 交叉运行尚未执行**。不得把下列 Python 参考执行与 Z3 结果改称“Rust 测试全部通过”。远端 GitHub Actions 配置已提供，但未运行，也未向任何远端仓库发布。

已执行与未执行的逐项状态、真实退出码、命令和源码指纹，以 [`results/validation/verification.json`](results/validation/verification.json) 为准。完整验证脚本遇到缺失的 Rust 工具会返回非零，不会静默降级为发布通过。

## 已实现的核心

四个运行时 Rust 包与三个研究 Rust 包，全部使用标准库，无 crates.io 依赖。另有可独立运行的 Python 参考实现、Z3 有限关系模型、定向场景、变异测试和复现脚本。

| 层次 | 实际实现 | 主要边界 |
| --- | --- | --- |
| Formation | 可执行布尔 DAG、实例/来源/权限/作用绑定、准入、执行及拒绝结果 | 关系决定真值，不接受 `path_ok`、`expected_verdict` 输入 |
| Evidence | 执行时事件采集、预声明契约、指定证据、收集器封存与监测摘要 | 采集器不读 Oracle；摘要不等于身份认证 |
| Checker | 单独可执行进程，从证据重新求值、审计五维、派生三种结论 | 不依赖 engine、scenarios、oracle；不读取场景标签 |
| Research | 隐藏运行事实、独立 Oracle、故障注入、逐项比较 | 研究真值只在 Checker 完成后用于评价 |
| Formal | 关系派生谓词、八组有限查询、见证搜索与反例重放 | 不链接 runtime；有限结果不冒充普遍证明 |
| System | 独立通道集合/执行图检查 | 不用系统级结果改写当前实例判定 |

## 第一个应当读懂的实验

`PAY-00` 对应 `E00`：四项适用检查真实控制付款准入。`PAY-01` 对应 `E03-S`：执行同样检查，但准入由不依赖这些评价的控制程序决定。当前输入下，两者都付款成功，普通观察逐字节相同。

结构证据包含实际执行的控制程序和准入依赖；检查器使用独立解释器，对有限评价空间重新求值。A 得到 `Conformant`，B 得到 `Non-conformant / Constraint`。删除 A 的指定关键证据后，形成事实不变，结果变为 `Unadjudicable`，不是“Constraint 已失败”。

这三种结果分别回答：**真实受控、已证实不受声明约束控制、当前无权下结论。**

## 快速运行

### 当前可以直接复现的参考执行

需要 Python 3.11+。完整参考验证还需要 Z3 动态库或 `z3` 命令；脚本不下载依赖。

```bash
python3 research/reference/run.py
python3 -m unittest discover -s research/tests -v
python3 formal/check.py
python3 scripts/verify.py --reference-only
```

`--reference-only` 成功，只表示指定参考/形式检查已执行通过；其报告仍保持 `release_ready: false`。没有 Z3 时形式步骤会失败，不会伪造 SAT/UNSAT。

### Rust 全量验证入口

先安装仓库锁定的 Rust 1.85.0 工具链，然后在仓库根目录运行：

```bash
python3 scripts/verify.py
```

该命令依次执行参考测试、场景、变异、Z3、见证重放、双次复现、两个 Rust workspace 的离线构建与测试、真实 Rust harness，以及 Rust/Python 的输入、证据和报告逐项对照。**只有全部实际执行通过，才写入 `release_ready: true`。**

分别构建和运行：

```bash
cargo build --manifest-path runtime/Cargo.toml --workspace --locked --offline
cargo test  --manifest-path runtime/Cargo.toml --workspace --locked --offline
cargo build --manifest-path research/Cargo.toml --workspace --locked --offline
cargo test  --manifest-path research/Cargo.toml --workspace --locked --offline
research/target/debug/isa-harness --checker runtime/target/debug/isa-checker --out results/rust
```

单例：在上述 harness 命令末尾加 `--scenario PAY-00` 或 `--scenario PAY-01`。Windows 可使用对应 `.exe` 路径及 `scripts/reproduce.ps1`。

重新审查一份归档证据，不读取 research-only 文件：

```bash
runtime/target/debug/isa-checker \
  --context results/reference/cases/E00/context.isa \
  --seal results/reference/cases/E00/collector-seal.isa \
  < results/reference/cases/E00/evidence.isa
```

## 结果在哪里

```text
runtime/                   四个运行时包，独立 Cargo workspace
research/                  三个研究包，另一个 Cargo workspace
  reference/               已执行的独立 Python 参考实现
  tests/                   参考测试和故意错误检查器的变异测试
formal/                    Z3 接口、SMT-LIB 查询、有限世界枚举
scripts/                   复现、隔离检查、跨语言验证、见证重放
results/
  reference/cases/          Checker 实际读取的上下文、封存和证据，以及输出
  reference/research-only/  独立 Oracle、原始运行事件，不传给 Checker
  reference/matrix.csv      22 个定向场景结果
  reference/pair.json       A/B 观察等价与非目标上下文一致性
  formal/                  实际 SAT/UNSAT、原始见证、枚举、重放
  validation/              实际命令日志、变异结果、复现结果、状态报告
  manifests/               文件校验和
```

原设计中的 E05-A/B、E06 是配对观察实验，复用 E00/E03-S，并单独输出 `pair.json`，不重复制造三份相同场景。两个 Gate A 测试分别映射为 `M1-APPLICABILITY` 与 `M2-CONTRACT / M2-CHERRY`。

## 这些结果支持什么

已生成的参考场景矩阵包含 22 个定向场景：5 个符合、8 个不符合、9 个不可判定，均与独立 Oracle 对照一致。**检测到故障是测试成功，不是该场景安全符合。**

Z3 实际完成八组中的 17 个查询，包括负面对照和非空性检查；另有 2,560 个有限世界的独立枚举。查询不仅重现主反例，也找到“程序证据不足以证明全部形成结构”和“信任根被攻破后出现虚假确定性”的边界反例。形式结果没有证明任意部署安全，也没有验证 Rust 编译结果。

测试数量和最新状态以生成报告为准，不使用定向场景通过率冒充真实业务安全概率。

## 最重要的信任边界

本实现使用 **synthetic collector root**：调用方提供可信的预声明上下文与独立收集器封存。校验和检测材料与封存是否一致；真实性、完整采集和隔离能力仍依赖声明的研究信任根。**攻击者若能同时伪造证据、监测摘要和可信输入，Checker 不能凭空识破。** 仓库把这种失败作为边界反例保存，而不是隐藏。

独立进程、清空环境、只传白名单输入可以防止本研究程序中的答案误传，但不是针对恶意主机或同权限任意文件读取的完整沙箱。生产鉴证、签名基础设施、硬件可信执行、动态分布式系统、真实 LLM 和真实支付均未在本包中验证。

详见 [SECURITY.md](SECURITY.md)、[可复现说明](docs/REPRODUCIBILITY.md)、[论文—代码—证据映射](docs/TRACEABILITY.md) 和 [实际差额账本](docs/decisions/ARTIFACT_DELTA.md)。

## 定义来源与参考项目

`docs/paper/` 保存 ISA v1.2 FINAL，`docs/anchors/` 保存用户提交的六份文档原件，SHA-256 在 `docs/SOURCE_REGISTRY.json`。原始文件保持不变；后发 Gate A 与 IMPL 的明确裁决覆盖较早的实现组织描述，不能覆盖论文定义。

参考第二篇工件仓库的研究组织、独立检查和结果复现方法，固定参考 commit：`b428ada1c4805cb9b1db20562ca44d185ac336a0`。本实现没有复制其 Rust 源码，也没有修改远端仓库。参考记录见 `docs/REFERENCE_REPOSITORY.json`。

软件代码按 Apache-2.0 随包提供。原论文与原始锚点文档不因被收入此包而自动改变其著作权或许可状态，见 `NOTICE`。没有生成或声称已取得 DOI、远端 release 或公开部署。
